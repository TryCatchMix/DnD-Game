import { Component, computed, inject, input, signal, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { JuegoService } from '../../core/juego.service';
import { ResolutionView, SceneOption, SceneView } from '../../core/api.types';
import { NavBar } from '../../shared/nav';

/**
 * Pantalla 04: la escena y la tirada.
 *
 * Dos actos y un cambio de luz entre ellos. Primero la escena es una hoja de
 * manuscrito: situación arriba, opciones abajo, cada una con su habilidad y su
 * CD. Al elegir, el mundo se apaga y solo queda el d20 girando sobre el fondo
 * oscuro; cuando se para, debajo aparecen las cuentas completas y la banda del
 * grado de resultado. El dado es el momento, no un detalle.
 */
@Component({
  selector: 'arc-scene',
  imports: [NavBar],
  template: `
    <arc-nav [personajeId]="personajeId()" />
    <div class="contenedor">

      @if (cargando()) {
        <p class="estado">Abriendo el expediente…</p>
      }

      @if (escena(); as sc) {
        <header class="cabecera">
          <div class="franja">
            <p class="rotulo">{{ sc.questTitle }}</p>
            <span class="cuenta-escenas">
              Escena {{ sc.sceneOrdinal }} de {{ sc.sceneCount }}
            </span>
          </div>
          <div class="barra progreso">
            <i [style.width.%]="sc.sceneCount ? (sc.sceneOrdinal / sc.sceneCount) * 100 : 0"></i>
          </div>
          <h1>{{ sc.title }}</h1>
        </header>

        <div class="hoja relato">
          <p>{{ sc.body }}</p>
        </div>

        @if (sc.waitingFor; as espera) {
          <p class="camino">
            Sigues en camino. Vuelve en <strong>{{ espera }}</strong>.
          </p>
        }

        @if (!resolucion() && !sc.waitingFor) {
          <p class="rotulo seccion">Qué haces</p>
          <ul class="opciones">
            @for (o of sc.options; track o.id) {
              <li>
                <button class="hoja opcion"
                        [disabled]="!o.affordable || eligiendo() !== null"
                        (click)="elegir(o)">
                  <span class="cuerpo-opcion">
                    <span class="etiqueta">{{ o.label }}</span>
                    <span class="prueba">
                      @if (o.skill) {
                        {{ o.skill }} · CD {{ o.dc }}
                      } @else {
                        Sin tirada
                      }
                      @if (o.vigorCost === 0) {
                        · No gasta Vigor
                      } @else {
                        · Vigor {{ o.vigorCost }}
                      }
                    </span>
                  </span>

                  <span class="margen">
                    @if (o.successChance !== null) {
                      <span class="pct">{{ o.successChance }} %</span>
                      <span class="pct-pie">éxito</span>
                    }
                    @if (o.risk) {
                      <span class="riesgo" [class]="'riesgo--' + o.risk.toLowerCase()">
                        {{ riesgoEnPalabras(o.risk) }}
                      </span>
                    }
                  </span>

                  @if (o.note) { <span class="nota">{{ o.note }}</span> }
                  @if (!o.affordable) { <span class="nota nota--mal">Te falta Vigor</span> }
                </button>
              </li>
            }
          </ul>
        }
      }

      @if (error(); as e) {
        <p class="estado estado--mal" role="alert">{{ e }}</p>
      }
    </div>

    <!-- ============ EL DADO: se come la pantalla ============ -->
    @if (resolucion(); as r) {
      <div class="tirada" [class]="'grado--' + (r.roll?.grade ?? 4)" role="dialog" aria-live="polite">
        <div class="tirada-interior">

          @if (r.roll; as roll) {
            <p class="rotulo prueba-tirada">Prueba contra CD {{ roll.dc }}</p>

            <div class="ruedo">
              <span class="halo" aria-hidden="true"></span>
              <span class="dado" aria-hidden="true"></span>
              <span class="valor">{{ roll.d20 }}</span>
            </div>

            <!-- El desglose completo. Enseñarlo es lo que hace que un fallo se
                 sienta justo en vez de arbitrario. -->
            <dl class="cuentas">
              <div class="cuenta">
                <dt>d20</dt>
                <dd>{{ roll.d20 }}</dd>
              </div>
              @for (m of roll.breakdown; track m.label) {
                <div class="cuenta">
                  <dt>{{ m.label }}</dt>
                  <dd [class.menos]="m.value < 0">
                    {{ m.value > 0 ? '+' : '' }}{{ m.value }}
                  </dd>
                </div>
              }
              <div class="cuenta cuenta--total">
                <dt>Total</dt>
                <dd>{{ roll.total }} vs CD {{ roll.dc }}</dd>
              </div>
            </dl>
          }

          <div class="veredicto">
            @if (r.roll; as roll) {
              <p class="grado">Grado {{ roll.grade }} de 5 · {{ roll.gradeLabel }}</p>
            }
            <p class="narrativa">{{ r.narrative }}</p>

            @if (r.changes.length > 0) {
              <ul class="cambios">
                @for (c of r.changes; track c) { <li>{{ c }}</li> }
              </ul>
            }

            @if (r.finished) {
              <p class="cierre">El encargo queda cerrado.</p>
              <button class="boton boton--claro" (click)="volverAlTablon()">
                Volver al tablón
              </button>
            } @else if (r.waitingFor) {
              <p class="cierre">Sigues en camino. Vuelve en <strong>{{ r.waitingFor }}</strong>.</p>
              <button class="boton boton--claro" (click)="volverAlTablon()">Volver al tablón</button>
            } @else {
              <button class="boton boton--claro" (click)="continuar()">Seguir</button>
            }
          </div>
        </div>
      </div>
    }
  `,
  styles: `
    /* ------------------------------------------------- acto 1: el manuscrito */
    .cabecera { margin-bottom: 18px; }
    .franja { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; }
    .cabecera .rotulo { color: var(--sepia-claro); margin: 0; }
    .cuenta-escenas {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .14em;
      text-transform: uppercase;
      color: var(--vino);
      white-space: nowrap;
    }
    .progreso { margin: 10px 0 14px; background: rgba(239,228,205,.14); }
    .cabecera h1 { font-size: 32px; color: var(--pergamino); line-height: 1.08; }

    .relato { padding: 24px 22px 22px; }
    .relato p { margin: 0; font-size: 19px; line-height: 1.6; color: var(--tinta); }

    .camino {
      font-family: var(--dato);
      font-size: 11px;
      letter-spacing: .06em;
      color: var(--oro);
      border-left: 2px solid var(--oro);
      padding: 10px 12px;
      margin: 16px 0 0;
      background: rgba(157,122,47,.08);
    }

    .seccion { color: var(--sepia-claro); }

    .opciones { list-style: none; margin: 0; padding: 0; display: grid; gap: 12px; }

    /* Cada opción es una tarjeta con dos columnas: lo que haces y lo que te
       cuesta. La probabilidad va al margen derecho, como una anotación. */
    .opcion {
      display: grid;
      grid-template-columns: 1fr auto;
      align-items: center;
      column-gap: 16px;
      width: 100%;
      text-align: left;
      padding: 18px;
      min-height: 84px;
      color: var(--tinta);
      transition: transform .12s ease, box-shadow .12s ease;
    }
    .opcion:hover:not(:disabled) {
      transform: translateY(-1px);
      box-shadow: 0 1px 0 rgba(255,255,255,.35) inset,
                  0 16px 32px rgba(0,0,0,.5);
    }
    .opcion:disabled { opacity: .45; }

    .cuerpo-opcion { display: grid; gap: 6px; min-width: 0; }
    .etiqueta { font-family: var(--cuerpo); font-size: 19px; line-height: 1.3; }
    .prueba {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .1em;
      text-transform: uppercase;
      color: var(--sepia);
    }

    .margen { text-align: right; display: grid; gap: 1px; white-space: nowrap; }
    .pct { font-family: var(--dato); font-size: 13px; color: var(--musgo); }
    .pct-pie {
      font-family: var(--dato);
      font-size: 9px;
      letter-spacing: .14em;
      text-transform: uppercase;
      color: var(--sepia);
    }
    .riesgo {
      font-family: var(--dato);
      font-size: 9px;
      letter-spacing: .12em;
      text-transform: uppercase;
    }
    .riesgo--high { color: var(--vino); }
    .riesgo--medium { color: var(--oro); }
    .riesgo--low { color: var(--musgo); }

    .nota {
      grid-column: 1 / -1;
      margin-top: 8px;
      font-style: italic;
      font-size: 15px;
      color: var(--sepia);
    }
    .nota--mal { color: var(--vino); font-style: normal; }

    /* ---------------------------------------------------- acto 2: el dado */
    .tirada {
      position: fixed;
      inset: 0;
      z-index: 40;
      overflow-y: auto;
      background: var(--noche-honda);
      background-image: radial-gradient(80% 55% at 50% 34%, rgba(157,122,47,.28), transparent 70%);
      color: var(--pergamino);
      animation: arc-entra .25s ease both;
    }
    .tirada-interior {
      max-width: 480px;
      margin: 0 auto;
      min-height: 100%;
      display: flex;
      flex-direction: column;
      padding: 28px 22px 40px;
    }

    .prueba-tirada { color: var(--oro); text-align: center; margin: 0; letter-spacing: .2em; }

    /* El ruedo: halo, dado y número. El dado gira poco menos de un segundo y
       el número aparece justo cuando se para. */
    .ruedo {
      position: relative;
      width: 210px; height: 210px;
      margin: 26px auto 8px;
      display: grid;
      place-items: center;
    }
    .halo {
      position: absolute; inset: 0;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(157,122,47,.45), transparent 65%);
      animation: arc-halo 3.2s ease-in-out .9s infinite both;
      opacity: 0;
    }
    .dado {
      position: absolute;
      width: 176px; height: 176px;
      clip-path: polygon(50% 0%, 93% 25%, 93% 75%, 50% 100%, 7% 75%, 7% 25%);
      background: linear-gradient(150deg, #f5ecd8 0%, #ddcfae 45%, #c4b28c 46%, #efe4cd 100%);
      box-shadow: 0 0 60px rgba(157,122,47,.45);
      animation: arc-dado-gira .9s linear both;
    }
    .valor {
      position: relative;
      font-family: var(--display);
      font-size: 84px;
      line-height: 1;
      color: var(--tinta);
      animation: arc-entra .35s ease .85s both;
      opacity: 0;
    }

    .cuentas {
      margin: 22px 0 0;
      padding: 18px 0 0;
      border-top: 1px solid var(--linea-noche);
      animation: arc-entra .3s ease 1s both;
    }
    .cuenta {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      gap: 12px;
      padding: 5px 0;
      font-family: var(--dato);
      font-size: 13px;
    }
    .cuenta dt { color: var(--sepia-claro); }
    .cuenta dd { margin: 0; color: var(--pergamino); font-variant-numeric: tabular-nums; }
    .cuenta .menos { color: #d98a7c; }
    .cuenta--total {
      border-top: 1px solid var(--linea-noche);
      margin-top: 4px;
      padding-top: 12px;
      font-size: 16px;
    }
    .cuenta--total dd { color: var(--oro-claro); }

    /* La banda del veredicto. El color es el grado: se lee antes que el texto. */
    .veredicto {
      margin: 26px -22px -40px;
      padding: 24px 22px 32px;
      background: var(--vino);
      animation: arc-entra .3s ease 1.15s both;
    }
    .grado--1 .veredicto, .grado--2 .veredicto { background: var(--vino); }
    .grado--3 .veredicto { background: var(--oro); }
    .grado--4 .veredicto { background: var(--musgo); }
    .grado--5 .veredicto { background: var(--musgo-hondo); }

    .grado {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .2em;
      text-transform: uppercase;
      color: rgba(255,255,255,.75);
      margin: 0 0 10px;
    }
    .narrativa {
      font-family: var(--display);
      font-size: 24px;
      line-height: 1.3;
      color: #fdf6e6;
      margin: 0;
    }

    .cambios { list-style: none; margin: 16px 0 0; padding: 0; display: grid; gap: 6px; }
    .cambios li {
      font-family: var(--dato);
      font-size: 11px;
      letter-spacing: .04em;
      color: #fdf6e6;
      border-left: 2px solid rgba(253,246,230,.5);
      padding: 4px 10px;
    }

    .cierre { font-style: italic; color: rgba(253,246,230,.8); margin: 16px 0 0; }

    .veredicto .boton--claro {
      margin-top: 20px;
      width: 100%;
      background: transparent;
      border-color: rgba(253,246,230,.5);
      color: #fdf6e6;
    }
    .veredicto .boton--claro:hover { background: rgba(253,246,230,.12); }

    .estado { font-style: italic; color: var(--sepia-claro); padding: 24px 0; }
    .estado--mal { color: #d98a7c; font-style: normal; }
  `,
})
export class ScenePage implements OnInit {

  readonly personajeId = input.required<string>();

  private readonly juego = inject(JuegoService);
  private readonly router = inject(Router);

  readonly escena = signal<SceneView | null>(null);
  readonly resolucion = signal<ResolutionView | null>(null);
  readonly cargando = signal(true);
  readonly eligiendo = signal<string | null>(null);
  readonly error = signal<string | null>(null);

  ngOnInit(): void { this.cargarEscena(); }

  elegir(o: SceneOption): void {
    if (this.eligiendo()) return;

    this.eligiendo.set(o.id);
    this.error.set(null);

    this.juego.elegir(this.personajeId(), o.id).subscribe({
      next: r => {
        this.eligiendo.set(null);
        this.resolucion.set(r);
      },
      error: err => {
        this.eligiendo.set(null);
        // 425 = sigue en camino, 409 = sin Vigor o encargo cerrado. En ambos
        // el backend manda el motivo con el tiempo exacto que falta.
        this.error.set(err?.error?.message ?? 'No se ha podido resolver la escena.');
      },
    });
  }

  continuar(): void {
    this.resolucion.set(null);
    this.cargando.set(true);
    this.cargarEscena();
  }

  volverAlTablon(): void {
    void this.router.navigate(['/personajes', this.personajeId(), 'tablon']);
  }

  riesgoEnPalabras(r: 'LOW' | 'MEDIUM' | 'HIGH'): string {
    return { LOW: 'Poco riesgo', MEDIUM: 'Riesgo', HIGH: 'Muy arriesgado' }[r];
  }

  private cargarEscena(): void {
    this.juego.escenaActual(this.personajeId()).subscribe({
      next: sc => { this.escena.set(sc); this.cargando.set(false); },
      error: err => {
        this.cargando.set(false);
        if (err?.status === 404) {
          void this.router.navigate(['/personajes', this.personajeId(), 'tablon']);
          return;
        }
        this.error.set('No se ha podido abrir el expediente.');
      },
    });
  }
}
