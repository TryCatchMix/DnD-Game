import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'arc-login',
  imports: [FormsModule],
  template: `
    <div class="marco">
      <div class="hoja carta">

        <!-- El sello es la firma visual: todo lo que hace el clan va lacrado. -->
        <div class="lacre" aria-hidden="true">
          <span>LA</span>
        </div>

        <p class="rotulo">Registro de intermisión</p>
        <h1>Los Archivos</h1>
        <p class="anno">Año 1127 después del Cataclismo · Ciudades Libres</p>

        <hr class="regla" />

        @if (auth.avisoDeSesion(); as aviso) {
          <p class="aviso" role="status">{{ aviso }}</p>
        }

        <form (ngSubmit)="entrar()">
          <label class="campo">
            <span class="rotulo">Nombre en el libro</span>
            <input name="email" type="email" autocomplete="username"
                   [(ngModel)]="email" required />
          </label>

          <label class="campo">
            <span class="rotulo">Contraseña</span>
            <input name="password" type="password" autocomplete="current-password"
                   [(ngModel)]="password" required />
          </label>

          @if (error(); as e) {
            <p class="error" role="alert">{{ e }}</p>
          }

          <button class="boton boton--lacre ancho" type="submit"
                  [disabled]="cargando() || !email() || !password()">
            {{ cargando() ? 'Cotejando…' : 'Entrar' }}
          </button>
        </form>
      </div>

      <p class="pie">Cotejan, registran y no preguntan dos veces.</p>
    </div>
  `,
  styles: `
    .marco {
      min-height: 100dvh;
      display: grid;
      place-content: center;
      gap: 20px;
      padding: 24px 18px;
      position: relative;
      z-index: 1;
    }

    .carta {
      width: min(420px, 92vw);
      padding: 56px 32px 34px;
      text-align: center;
      position: relative;
      /* Luz cayendo sobre la parte de arriba de la hoja, como en el mockup. */
      background-image:
        var(--veta),
        radial-gradient(120% 80% at 50% 0%, rgba(255,251,238,.65), transparent 60%),
        radial-gradient(140% 100% at 50% 100%, rgba(120,92,52,.16), transparent 55%);
    }

    /* Lacre: círculo de cera con las iniciales del clan. Es el único elemento
       decorativo de toda la interfaz, y va aquí porque entrar es el momento en
       que te identificas ante Los Archivos. */
    .lacre {
      position: absolute;
      top: -30px; left: 50%;
      transform: translateX(-50%) rotate(-4deg);
      width: 76px; height: 76px;
      border-radius: 50%;
      background: var(--vino);
      border: 1px solid rgba(0,0,0,.35);
      box-shadow: 0 8px 16px -6px rgba(0,0,0,.55),
                  0 -6px 12px rgba(0,0,0,.28) inset,
                  0 6px 10px rgba(255,255,255,.16) inset;
      display: grid; place-content: center;
    }
    .lacre span {
      font-family: var(--display);
      font-size: 28px;
      letter-spacing: .06em;
      color: #f3dcc9;
    }

    h1 {
      font-size: 40px;
      line-height: 1.05;
      letter-spacing: .01em;
      margin: 10px 0 8px;
      color: var(--tinta);
    }

    .anno {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .2em;
      text-transform: uppercase;
      color: var(--sepia);
      margin: 0;
    }

    .regla {
      border: 0;
      border-top: 1px solid var(--linea);
      margin: 26px 0 22px;
    }

    .campo { display: block; text-align: left; margin-bottom: 16px; }
    .campo .rotulo { display: block; margin-bottom: 6px; }

    .ancho { width: 100%; margin-top: 10px; }

    .error, .aviso {
      font-size: 14px;
      text-align: left;
      border-left: 2px solid var(--vino);
      padding: 8px 12px;
      margin: 0 0 14px;
      color: var(--sepia-hondo);
      background: rgba(143,46,34,.06);
    }
    .aviso { border-left-color: var(--oro); background: rgba(157,122,47,.08); }

    .pie {
      font-family: var(--cuerpo);
      font-style: italic;
      font-size: 15px;
      color: var(--sepia);
      text-align: center;
      margin: 0;
    }
  `,
})
export class LoginPage {

  readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  readonly email = signal('');
  readonly password = signal('');
  readonly cargando = signal(false);
  readonly error = signal<string | null>(null);

  entrar(): void {
    if (this.cargando()) return;

    this.cargando.set(true);
    this.error.set(null);

    this.auth.login(this.email(), this.password()).subscribe({
      next: () => {
        this.cargando.set(false);
        void this.router.navigate(['/personajes']);
      },
      error: err => {
        this.cargando.set(false);
        // El backend devuelve el mismo mensaje para correo inexistente y
        // contraseña mala, a propósito. Lo mostramos tal cual.
        this.error.set(err?.error?.message ?? 'No se ha podido comprobar el registro.');
      },
    });
  }
}
