import { Component, computed, inject, input, signal, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { JuegoService } from '../../core/juego.service';
import { AuthService } from '../../core/auth.service';
import { ChronicleEntry } from '../../core/api.types';
import { NavBar } from '../../shared/nav';

const CATEGORIAS = ['MUNDO', 'CATACLISMO', 'VERDAD', 'CLAN', 'RUMOR'];

/**
 * Pantalla 07: la crónica del clan. La memoria compartida del mundo.
 *
 * Es un tablón de anuncios leído de arriba abajo: cada entrada lleva su
 * glifo de categoría a la izquierda, el titular en tipografía de display y el
 * texto sangrado como una cita. Lo sellado se ve pero no se lee: la Orden del
 * Velo tapa, Los Archivos destapan.
 */
@Component({
  selector: 'arc-cronica',
  imports: [NavBar, FormsModule],
  template: `
    <arc-nav [personajeId]="personajeId()" />

    <div class="contenedor">
      <header class="cabecera">
        <p class="rotulo">Crónica del clan · Los Archivos</p>
        <h1>Lo que quede constancia</h1>
        <p class="intro">
          La Orden del Velo sella lo que de verdad pasó en el Cataclismo. El clan
          copia, coteja y destapa. Aquí queda escrito.
        </p>
      </header>

      @if (esDM()) {
        <div class="anotar">
          @if (!mostrarAnotar()) {
            <button class="boton" (click)="mostrarAnotar.set(true)">+ Anotar en la crónica</button>
          } @else {
            <form class="hoja formulario" (ngSubmit)="anotar()">
              <p class="rotulo">Nueva entrada</p>
              <label>Título<input name="c_title" [(ngModel)]="nueva.title" required /></label>
              <div class="fila-form">
                <label>Año<input name="c_year" type="number" [(ngModel)]="nueva.year" /></label>
                <label>Época<input name="c_era" [(ngModel)]="nueva.era" placeholder="Año 1127 · Dorakan" /></label>
                <label>Categoría
                  <select name="c_cat" [(ngModel)]="nueva.category">
                    @for (c of categorias; track c) { <option [value]="c">{{ c }}</option> }
                  </select>
                </label>
              </div>
              <label>Facción<input name="c_fac" [(ngModel)]="nueva.faction" placeholder="Los Archivos, La Orden del Velo…" /></label>
              <label>Texto<textarea name="c_body" rows="3" [(ngModel)]="nueva.body"></textarea></label>
              <label class="check">
                <input name="c_sealed" type="checkbox" [(ngModel)]="nueva.sealed" />
                Sellar (verdad oculta por la Orden del Velo)
              </label>
              @if (errorAnotar(); as e) { <p class="error">{{ e }}</p> }
              <div class="acciones">
                <button class="boton boton--lacre" type="submit" [disabled]="guardando()">
                  {{ guardando() ? 'Anotando…' : 'Anotar' }}
                </button>
                <button class="boton" type="button" (click)="cancelarAnotar()">Cancelar</button>
              </div>
            </form>
          }
        </div>
      }

      @if (cargando()) {
        <p class="estado">Abriendo la crónica…</p>
      } @else if (error(); as e) {
        <p class="estado estado--mal" role="alert">{{ e }}</p>
      } @else {
        <ol class="hoja linea">
          @for (e of entradas(); track e.id) {
            <li class="entrada"
                [class.sellada]="e.sealed && !e.revealed"
                [class.revelada]="e.sealed && e.revealed">

              <!-- El glifo: inicial de la categoría en un lacre. Sirve para
                   distinguir de un vistazo mundo, clan, verdad y rumor. -->
              <span class="glifo" [class]="'glifo--' + e.category.toLowerCase()" aria-hidden="true">
                {{ etiqueta(e.category).charAt(0) }}
              </span>

              <div class="cuerpo-entrada">
                <div class="franja">
                  <span class="era">{{ e.era }}</span>
                  <span class="cat" [class]="'cat--' + e.category.toLowerCase()">{{ etiqueta(e.category) }}</span>
                </div>

                <h2>{{ e.title }}</h2>

                @if (e.faction) {
                  <p class="faccion" [class.velo]="e.faction === 'La Orden del Velo'">{{ e.faction }}</p>
                }

                @if (e.sealed && !e.revealed) {
                  <div class="sello" aria-hidden="true"><span>SELLADO</span></div>
                  <p class="cuerpo censurado">{{ e.body }}</p>
                  @if (e.canReveal) {
                    <button class="boton boton--lacre revelar"
                            [disabled]="revelando() === e.id"
                            (click)="revelar(e)">
                      {{ revelando() === e.id ? 'Destapando…' : 'Destapar la verdad' }}
                    </button>
                  }
                } @else {
                  @if (e.sealed && e.revealed) {
                    <p class="destapada">✦ Verdad destapada por Los Archivos</p>
                  }
                  <p class="cuerpo">{{ e.body }}</p>
                }
              </div>
            </li>
          }
        </ol>

        <p class="pie-cronica">Todo lo de aquí se puede mencionar en la mesa</p>
      }
    </div>
  `,
  styles: `
    .cabecera { margin: 18px 0 20px; }
    .cabecera .rotulo { color: var(--sepia-claro); }
    .cabecera h1 { font-size: 30px; color: var(--pergamino); margin-top: 6px; line-height: 1.1; }
    .intro { color: var(--sepia-claro); font-style: italic; margin: 10px 0 0; max-width: 52ch; }

    /* anotar */
    .anotar { margin-bottom: 20px; }
    .formulario { padding: 16px 18px; display: grid; gap: 10px; }
    .formulario label { display: grid; gap: 4px; font-family: var(--dato); font-size: 9px; letter-spacing: .1em; text-transform: uppercase; color: var(--sepia); }
    .formulario textarea { resize: vertical; }
    .fila-form { display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 10px; }
    .check { flex-direction: row; align-items: center; gap: 8px; display: flex !important; text-transform: none; letter-spacing: normal; font-size: 12px; color: var(--sepia-hondo); }
    .check input { width: auto; }
    .acciones { display: flex; gap: 10px; flex-wrap: wrap; margin-top: 4px; }

    /* El libro: una sola hoja con filetes. Se lee como un registro, no como
       un muro de tarjetas. */
    .linea { list-style: none; margin: 0; padding: 0; overflow: hidden; }

    .entrada {
      display: grid;
      grid-template-columns: 36px 1fr;
      gap: 14px;
      padding: 20px 20px;
      border-bottom: 1px solid var(--linea-clara);
      position: relative;
    }
    .entrada:last-child { border-bottom: 0; }

    .glifo {
      width: 36px; height: 36px;
      border-radius: 50%;
      display: grid; place-content: center;
      font-family: var(--display);
      font-size: 17px;
      color: var(--pergamino);
      background: var(--tinta);
      box-shadow: 0 -2px 5px rgba(0,0,0,.28) inset;
    }
    .glifo--cataclismo { background: var(--vino); }
    .glifo--verdad { background: var(--oro); }
    .glifo--clan { background: var(--musgo); }
    .glifo--rumor { background: transparent; border: 1px solid var(--linea-fuerte); color: var(--sepia); box-shadow: none; }

    .cuerpo-entrada { min-width: 0; }

    .franja { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin-bottom: 6px; }
    .era { font-family: var(--dato); font-size: 10px; letter-spacing: .12em; text-transform: uppercase; color: var(--sepia); }
    .cat { font-family: var(--dato); font-size: 9px; letter-spacing: .14em; text-transform: uppercase; white-space: nowrap; }
    .cat--cataclismo { color: var(--vino); }
    .cat--verdad { color: var(--oro); }
    .cat--clan { color: var(--musgo); }
    .cat--mundo { color: var(--sepia); }
    .cat--rumor { color: var(--sepia-claro); }

    h2 { font-size: 23px; color: var(--tinta); line-height: 1.15; }
    .faccion { font-family: var(--dato); font-size: 10px; letter-spacing: .1em; text-transform: uppercase; color: var(--sepia); margin: 8px 0 0; }
    .faccion.velo { color: var(--vino); }

    /* El texto va sangrado con filete: es la voz del cronista citando. */
    .cuerpo {
      color: var(--sepia-hondo);
      font-size: 17px;
      line-height: 1.5;
      margin: 10px 0 0;
      padding-left: 12px;
      border-left: 2px solid rgba(143,46,34,.4);
      font-style: italic;
    }
    .destapada { font-family: var(--dato); font-size: 10px; letter-spacing: .1em; text-transform: uppercase; color: var(--oro); margin: 10px 0 0; }

    /* sellada */
    .entrada.sellada { background: rgba(43,33,23,.05); }
    .censurado { color: var(--sepia); filter: blur(2.5px); user-select: none; border-left-color: var(--linea-fuerte); }
    .sello {
      position: absolute; top: 16px; right: 18px;
      transform: rotate(-8deg);
      border: 2px double var(--vino);
      border-radius: var(--radio);
      padding: 3px 9px;
      opacity: .85;
      animation: arc-sello .5s cubic-bezier(.2,1.4,.4,1) both;
    }
    .sello span { font-family: var(--dato); font-size: 11px; letter-spacing: .18em; color: var(--vino); }
    .revelar { margin-top: 14px; }
    .entrada.revelada { box-shadow: inset 3px 0 0 var(--oro); }

    .pie-cronica {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .12em;
      text-transform: uppercase;
      color: var(--sepia);
      text-align: center;
      margin: 18px 0 0;
    }

    .error { font-size: 13px; color: #d98a7c; border-left: 2px solid var(--vino); padding: 4px 10px; margin: 0; }
    .estado { font-style: italic; color: var(--sepia-claro); padding: 24px 0; }
    .estado--mal { color: #d98a7c; font-style: normal; }
  `,
})
export class CronicaPage implements OnInit {

  readonly personajeId = input.required<string>();

  private readonly juego = inject(JuegoService);
  private readonly auth = inject(AuthService);

  readonly categorias = CATEGORIAS;
  readonly esDM = computed(() => this.auth.rol() === 'DM');

  readonly entradas = signal<ChronicleEntry[]>([]);
  readonly cargando = signal(true);
  readonly error = signal<string | null>(null);
  readonly revelando = signal<string | null>(null);

  readonly mostrarAnotar = signal(false);
  readonly guardando = signal(false);
  readonly errorAnotar = signal<string | null>(null);
  nueva = this.entradaVacia();

  ngOnInit(): void {
    this.juego.cronica().subscribe({
      next: cs => { this.entradas.set(cs); this.cargando.set(false); },
      error: () => {
        this.cargando.set(false);
        this.error.set('No se ha podido abrir la crónica.');
      },
    });
  }

  revelar(e: ChronicleEntry): void {
    if (this.revelando()) return;
    this.revelando.set(e.id);
    this.juego.revelar(e.id).subscribe({
      next: cs => { this.entradas.set(cs); this.revelando.set(null); },
      error: () => { this.revelando.set(null); this.error.set('No se ha podido destapar la entrada.'); },
    });
  }

  anotar(): void {
    if (this.guardando()) return;
    if (!this.nueva.title || !this.nueva.title.trim()) {
      this.errorAnotar.set('La entrada necesita un título.');
      return;
    }
    this.guardando.set(true);
    this.errorAnotar.set(null);
    this.juego.anotar(this.nueva).subscribe({
      next: cs => {
        this.entradas.set(cs);
        this.guardando.set(false);
        this.mostrarAnotar.set(false);
        this.nueva = this.entradaVacia();
      },
      error: err => {
        this.guardando.set(false);
        this.errorAnotar.set(err?.error?.message ?? 'No se ha podido anotar.');
      },
    });
  }

  cancelarAnotar(): void {
    this.mostrarAnotar.set(false);
    this.errorAnotar.set(null);
    this.nueva = this.entradaVacia();
  }

  etiqueta(cat: string): string {
    switch (cat) {
      case 'CATACLISMO': return 'Cataclismo';
      case 'MUNDO': return 'Mundo';
      case 'VERDAD': return 'Verdad';
      case 'CLAN': return 'Clan';
      case 'RUMOR': return 'Rumor';
      default: return cat;
    }
  }

  private entradaVacia() {
    return { title: '', year: 1127, era: 'Año 1127 · Dorakan', category: 'MUNDO', faction: '', body: '', sealed: false };
  }
}
