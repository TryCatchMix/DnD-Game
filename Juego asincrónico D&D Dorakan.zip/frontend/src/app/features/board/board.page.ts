import { Component, computed, inject, input, signal, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { JuegoService } from '../../core/juego.service';
import { QuestCard } from '../../core/api.types';
import { NavBar } from '../../shared/nav';

@Component({
  selector: 'arc-board',
  imports: [NavBar],
  template: `
    <arc-nav [personajeId]="personajeId()" />
    <div class="contenedor">
      <header class="cabecera">
        <p class="rotulo">Tablón de encargos · Dorakan</p>
        <h1>Qué hay para hoy</h1>
        @if (!cargando() && encargos().length > 0) {
          <p class="recuento">{{ encargos().length }} encargos clavados en el tablón</p>
        }
      </header>

      <!-- Los filtros del mockup: el jugador entra dos veces al día y busca
           una cosa concreta ("algo barato", "algo con el clan"). -->
      @if (!cargando() && encargos().length > 0) {
        <div class="filtros" role="group" aria-label="Filtrar encargos">
          <button class="filtro" [class.puesto]="filtro() === 'TODOS'"
                  (click)="filtro.set('TODOS')">Todos</button>
          <button class="filtro" [class.puesto]="filtro() === 'GRUPO'"
                  (click)="filtro.set('GRUPO')">En grupo</button>
          <button class="filtro" [class.puesto]="filtro() === 'BARATO'"
                  (click)="filtro.set('BARATO')">1 Vigor</button>
          <button class="filtro" [class.puesto]="filtro() === 'FACCION'"
                  (click)="filtro.set('FACCION')">Con facción</button>
        </div>
      }

      @if (cargando()) {
        <p class="estado">Cotejando el tablón…</p>
      } @else if (error(); as e) {
        <p class="estado estado--mal" role="alert">{{ e }}</p>
      } @else if (encargos().length === 0) {
        <p class="estado">
          No hay nada clavado en el tablón. Vuelve cuando el capataz baje del pozo.
        </p>
      } @else {

        @if (jugables().length === 0 && bloqueados().length > 0) {
          <p class="estado">Ningún encargo cuadra con ese filtro.</p>
        }

        @if (jugables().length > 0) {
          <ul class="lista">
            @for (q of jugables(); track q.id) {
              <li class="hoja tarjeta" [class.tarjeta--curso]="q.availability === 'JOINED'">

                <!-- Cintillo de estado: lo primero que se lee. En curso manda. -->
                <div class="cintillo">
                  @if (q.availability === 'JOINED') {
                    <span class="marca marca--curso">En curso</span>
                  } @else if (q.availability === 'RECRUITING') {
                    <span class="marca marca--recluta">Buscando gente</span>
                  } @else {
                    <span class="marca">Disponible</span>
                  }
                  @if (q.closesIn) { <span class="reloj">{{ q.closesIn }}</span> }
                </div>

                <h2>{{ q.title }}</h2>

                <div class="cintas">
                  <span class="chip">{{ q.sceneCount }} escenas</span>
                  <span class="chip">{{ q.duration }}</span>
                  <span class="chip chip--vigor">{{ q.vigorCost }} Vigor</span>
                  @if (q.faction) { <span class="chip chip--faccion">{{ q.faction }}</span> }
                </div>

                <p class="gancho">{{ q.hook }}</p>

                <div class="pie-tarjeta">
                  @if (q.skills.length > 0) {
                    <span class="habilidades">
                      @for (s of q.skills; track s) { <span>{{ s }}</span> }
                    </span>
                  }
                  @if (q.rewardNote) { <span class="premio">{{ q.rewardNote }}</span> }
                </div>

                @if (q.signatures) {
                  <p class="firmas">{{ q.signatures }}</p>
                }

                <button class="boton"
                        [class.boton--lacre]="q.availability !== 'JOINED'"
                        [class.boton--tinta]="q.availability === 'JOINED'"
                        [disabled]="firmando() === q.id"
                        (click)="firmar(q)">
                  {{ firmando() === q.id ? 'Firmando…'
                     : q.availability === 'JOINED' ? 'Continuar' : 'Firmar · ' + q.vigorCost + ' Vigor' }}
                </button>
              </li>
            }
          </ul>
        }

        <!-- Los bloqueados NO se ocultan. Ver "requiere Puente Norte en pie" es
             lo que le cuenta al jugador que otro cambió el mundo. -->
        @if (bloqueados().length > 0) {
          <p class="rotulo seccion">Fuera de tu alcance ahora mismo</p>
          <ul class="lista">
            @for (q of bloqueados(); track q.id) {
              <li class="hoja tarjeta tarjeta--gris">
                <div class="cintillo">
                  <span class="marca marca--cerrado">Bloqueado</span>
                </div>
                <h2>{{ q.title }}</h2>
                <p class="gancho">{{ q.hook }}</p>
                <p class="motivo">{{ q.reason }}</p>
              </li>
            }
          </ul>
        }
      }
    </div>
  `,
  styles: `
    .cabecera { margin-bottom: 16px; }
    .cabecera h1 { font-size: 30px; color: var(--pergamino); margin-top: 6px; line-height: 1.1; }
    .cabecera .rotulo { color: var(--sepia-claro); }
    .recuento {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .12em;
      text-transform: uppercase;
      color: var(--sepia);
      margin: 8px 0 0;
    }

    /* Filtros: píldoras planas; la puesta va en pergamino lleno. */
    .filtros { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 18px; }
    .filtro {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .12em;
      text-transform: uppercase;
      color: var(--sepia-claro);
      background: transparent;
      border: 1px solid var(--linea-noche);
      border-radius: var(--radio);
      padding: 9px 13px;
    }
    .filtro:hover { color: var(--pergamino); }
    .filtro.puesto {
      background: var(--pergamino);
      border-color: var(--pergamino);
      color: var(--tinta);
    }

    .lista { list-style: none; margin: 0 0 8px; padding: 0; display: grid; gap: 12px; }

    .tarjeta { padding: 18px 20px 18px; display: grid; gap: 12px; }

    /* El encargo en curso lleva el papel tintado de lacre: cuando entras dos
       veces al día, esto es lo único que necesitas encontrar. */
    .tarjeta--curso {
      background-image: var(--veta),
        linear-gradient(0deg, rgba(143,46,34,.07), rgba(143,46,34,.07));
      border-color: rgba(143,46,34,.45);
    }

    .cintillo { display: flex; align-items: center; justify-content: space-between; gap: 10px; }
    .marca {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .16em;
      text-transform: uppercase;
      color: var(--sepia);
    }
    .marca--curso { color: var(--vino); }
    .marca--recluta { color: var(--musgo); }
    .marca--cerrado { color: var(--sepia-hondo); border: 1px solid var(--linea-fuerte); border-radius: var(--radio); padding: 3px 7px; }
    .reloj { font-family: var(--dato); font-size: 12px; color: var(--vino); white-space: nowrap; }

    h2 { font-size: 24px; color: var(--tinta); line-height: 1.15; }

    .cintas { display: flex; flex-wrap: wrap; gap: 6px; }

    .gancho {
      font-size: 17px;
      color: var(--sepia-hondo);
      margin: 0;
      line-height: 1.45;
    }

    /* Habilidades a la izquierda, recompensa a la derecha: la decisión del
       jugador es siempre "¿tengo yo esa habilidad y me paga bastante?". */
    .pie-tarjeta {
      display: flex;
      align-items: baseline;
      justify-content: space-between;
      gap: 12px;
      flex-wrap: wrap;
      border-top: 1px solid var(--linea-clara);
      padding-top: 12px;
    }
    .habilidades { display: flex; flex-wrap: wrap; gap: 4px 10px; }
    .habilidades span {
      font-family: var(--dato);
      font-size: 11px;
      letter-spacing: .06em;
      text-transform: uppercase;
      color: var(--sepia);
    }
    .premio {
      font-family: var(--dato);
      font-size: 13px;
      color: var(--oro);
      white-space: nowrap;
    }

    .firmas {
      font-family: var(--dato);
      font-size: 11px;
      color: var(--musgo);
      margin: -4px 0 0;
    }

    /* Bloqueado: se apaga el papel, no se esconde la tarjeta. */
    .tarjeta--gris {
      background: var(--pergamino-hueso);
      background-image: none;
      opacity: .6;
      box-shadow: none;
    }
    .tarjeta--gris h2 { color: var(--sepia-hondo); }

    .motivo {
      font-family: var(--dato);
      font-size: 11px;
      letter-spacing: .06em;
      text-transform: uppercase;
      color: var(--vino);
      border-top: 1px solid var(--linea-clara);
      padding-top: 12px;
      margin: 0;
    }

    .seccion { color: var(--sepia); }

    .estado {
      font-style: italic;
      color: var(--sepia-claro);
      padding: 28px 0;
    }
    .estado--mal { color: #d98a7c; font-style: normal; }
  `,
})
export class BoardPage implements OnInit {

  /** Llega de la ruta /personajes/:personajeId/tablon */
  readonly personajeId = input.required<string>();

  private readonly juego = inject(JuegoService);
  private readonly router = inject(Router);

  readonly encargos = signal<QuestCard[]>([]);
  readonly cargando = signal(true);
  readonly error = signal<string | null>(null);
  readonly firmando = signal<string | null>(null);

  /** Filtro de la barra: solo afecta a lo que se pinta, nada al servidor. */
  readonly filtro = signal<'TODOS' | 'GRUPO' | 'BARATO' | 'FACCION'>('TODOS');

  readonly jugables = computed(() =>
    this.encargos()
      .filter(q => this.esJugable(q.availability))
      .filter(q => this.pasaFiltro(q)));

  readonly bloqueados = computed(() =>
    this.encargos().filter(q => !this.esJugable(q.availability)));

  ngOnInit(): void {
    this.juego.tablon(this.personajeId()).subscribe({
      next: qs => { this.encargos.set(qs); this.cargando.set(false); },
      error: () => {
        this.cargando.set(false);
        this.error.set('No se ha podido leer el tablón. Inténtalo otra vez.');
      },
    });
  }

  firmar(q: QuestCard): void {
    if (q.availability === 'JOINED') {
      void this.router.navigate(['/personajes', this.personajeId(), 'escena']);
      return;
    }

    this.firmando.set(q.id);
    this.juego.firmar(this.personajeId(), q.id).subscribe({
      next: () => {
        this.firmando.set(null);
        void this.router.navigate(['/personajes', this.personajeId(), 'escena']);
      },
      error: err => {
        this.firmando.set(null);
        // 409 trae el motivo real ("Ya estás en otro encargo", "Requiere:
        // Puente Norte en pie"). Es más útil que un mensaje genérico.
        this.error.set(err?.error?.message ?? 'No se ha podido firmar el encargo.');
      },
    });
  }

  verFicha(): void {
    void this.router.navigate(['/personajes', this.personajeId(), 'ficha']);
  }

  verTienda(): void {
    void this.router.navigate(['/personajes', this.personajeId(), 'tienda']);
  }

  cambiarPersonaje(): void {
    void this.router.navigate(['/personajes']);
  }

  private esJugable(a: QuestCard['availability']): boolean {
    return a === 'AVAILABLE' || a === 'RECRUITING' || a === 'JOINED';
  }

  private pasaFiltro(q: QuestCard): boolean {
    switch (this.filtro()) {
      case 'GRUPO':   return q.availability === 'RECRUITING' || !!q.signatures;
      case 'BARATO':  return q.vigorCost <= 1;
      case 'FACCION': return !!q.faction;
      default:        return true;
    }
  }
}
