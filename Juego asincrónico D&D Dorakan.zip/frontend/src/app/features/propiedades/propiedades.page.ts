import { Component, computed, inject, input, signal, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { JuegoService } from '../../core/juego.service';
import { Holdings, Property, PropertyCatalogItem } from '../../core/api.types';
import { NavBar } from '../../shared/nav';

/**
 * El juego de propiedades: compra un negocio, recauda su renta, súbelo de
 * nivel y véndelo si quieres. Todo el dinero pasa por el monedero del
 * personaje. La renta se acumula sola con el tiempo (el backend la calcula);
 * aquí solo se recauda.
 *
 * Cada propiedad se puede abrir: entonces baja a pantalla completa la escena
 * de la propiedad trabajando (la mina tiene picador, chispas y vagoneta; los
 * demás negocios, su taller con el candil y el montón de monedas creciendo).
 * Es una animación de CSS, no hay imágenes: la propiedad se ve viva antes de
 * que el jugador recaude.
 */
@Component({
  selector: 'arc-propiedades',
  imports: [NavBar, FormsModule],
  template: `
    <arc-nav [personajeId]="personajeId()" />
    <div class="contenedor">
      <header class="cabecera">
        <p class="rotulo">Posesiones</p>
        <div class="titulo">
          <h1>Propiedades</h1>
          @if (datos(); as d) {
            <span class="monedero" title="Tu monedero">{{ d.purse }}</span>
          }
        </div>
      </header>

      @if (cargando()) {
        <p class="estado">Revisando las escrituras…</p>
      } @else if (error(); as e) {
        <p class="estado estado--mal" role="alert">{{ e }}</p>
      } @else if (datos(); as d) {

        <!-- Tus propiedades -->
        <p class="rotulo separador">Tus propiedades</p>
        @if (d.properties.length === 0) {
          <p class="vacio">Todavía no tienes ninguna. Compra la primera abajo.</p>
        } @else {
          <ul class="lista">
            @for (p of d.properties; track p.id) {
              <li class="hoja negocio">
                <div class="neg-cabe">
                  <span class="emoji" aria-hidden="true">{{ p.emoji }}</span>
                  <div class="neg-id">
                    <h2>{{ p.name }}</h2>
                    <p class="neg-sub">{{ p.tipo }} · {{ p.city }}</p>
                  </div>
                  <div class="nivel" [title]="'Nivel ' + p.level + ' de ' + p.maxLevel">
                    @for (n of niveles(p.maxLevel); track n) {
                      <span class="punto" [class.lleno]="n <= p.level"></span>
                    }
                  </div>
                </div>

                <dl class="neg-datos">
                  <div><dt>Renta</dt><dd>{{ p.incomePerDay }}</dd></div>
                  <div class="acumulado">
                    <dt>Acumulado</dt>
                    <dd [class.hay]="p.pendingCp > 0">{{ p.pending }}</dd>
                  </div>
                </dl>

                <!-- Entrar a ver la propiedad trabajando -->
                <button class="ver-obra" (click)="abrir(p)">
                  <span class="ver-texto">Bajar a verla trabajar</span>
                  <span class="ver-flecha" aria-hidden="true">→</span>
                </button>

                <div class="neg-acc">
                  <button class="boton boton--lacre"
                          [disabled]="p.pendingCp <= 0 || !!ocupado()"
                          (click)="recaudar(p)">
                    {{ ocupado() === p.id ? '…' : 'Recaudar' }}
                  </button>

                  @if (p.upgradeCost) {
                    <button class="boton"
                            [disabled]="d.purseCp < (p.upgradeCostCp ?? 0) || !!ocupado()"
                            [title]="d.purseCp < (p.upgradeCostCp ?? 0) ? 'No te llega para la mejora' : ''"
                            (click)="mejorar(p)">
                      Mejorar · {{ p.upgradeCost }}
                    </button>
                  } @else {
                    <span class="tope">Nivel máximo</span>
                  }

                  <button class="boton-quitar" title="Vender la propiedad"
                          [disabled]="!!ocupado()"
                          (click)="vender(p)">
                    Vender · {{ p.saleValue }}
                  </button>
                </div>
              </li>
            }
          </ul>
        }

        <!-- Catálogo -->
        <p class="rotulo separador">Comprar una propiedad</p>
        <ul class="catalogo">
          @for (c of d.catalog; track c.kind) {
            <li class="hoja tipo">
              <div class="tipo-cabe">
                <span class="emoji" aria-hidden="true">{{ c.emoji }}</span>
                <h3>{{ c.nombre }}</h3>
              </div>
              <p class="tipo-blurb">{{ c.blurb }}</p>
              <p class="tipo-datos">
                <span class="precio">{{ c.buyPrice }}</span>
                <span class="renta">{{ c.incomePerDay }}</span>
              </p>

              @if (eligiendo() === c.kind) {
                <div class="compra">
                  <input class="nombre" type="text" maxlength="80"
                         placeholder="Ponle un nombre…"
                         [(ngModel)]="nombre" (keyup.enter)="confirmar(c)" />
                  <div class="compra-acc">
                    <button class="boton boton--lacre" [disabled]="!!ocupado()"
                            (click)="confirmar(c)">Confirmar</button>
                    <button class="boton" [disabled]="!!ocupado()"
                            (click)="cancelar()">Cancelar</button>
                  </div>
                </div>
              } @else {
                <button class="boton boton--lacre ancho"
                        [disabled]="d.purseCp < c.buyPriceCp || !!ocupado()"
                        [title]="d.purseCp < c.buyPriceCp ? 'No te llega el dinero' : ''"
                        (click)="elegir(c)">
                  Comprar
                </button>
              }
            </li>
          }
        </ul>
      }
    </div>

    <!-- ================= LA PROPIEDAD TRABAJANDO ================= -->
    @if (abierta(); as p) {
      <div class="obra" role="dialog" aria-label="La propiedad trabajando">
        <div class="obra-interior">

          <div class="obra-cabe">
            <div>
              <p class="rotulo">{{ esMina(p) ? 'Galería en obra' : 'El taller en marcha' }}</p>
              <h2>{{ p.name }}</h2>
            </div>
            <button class="cerrar" (click)="cerrar()" aria-label="Subir">✕</button>
          </div>

          <!-- ===== escena de la mina ===== -->
          @if (esMina(p)) {
            <div class="escena escena--mina">
              <div class="estratos" aria-hidden="true"></div>

              <!-- candil colgado del techo, respirando -->
              <span class="cable" aria-hidden="true"></span>
              <span class="halo" aria-hidden="true"></span>
              <span class="llama" aria-hidden="true"></span>

              <!-- goteo del techo -->
              <span class="gota gota--a" aria-hidden="true"></span>
              <span class="gota gota--b" aria-hidden="true"></span>

              <!-- la veta que están picando -->
              <span class="veta" aria-hidden="true"></span>
              <span class="veta veta--fina" aria-hidden="true"></span>

              <!-- el picador: cuerpo + pico pivotando en el hombro -->
              <div class="picador" aria-hidden="true">
                <div class="pico">
                  <span class="mango"></span>
                  <span class="hoja-pico"></span>
                </div>
                <span class="tronco"></span>
                <span class="pecho"></span>
                <span class="cabeza"></span>
                <span class="casco"></span>
              </div>

              <!-- chispas del golpe, sincronizadas con la caída del pico -->
              <div class="chispas" aria-hidden="true">
                <span style="--dx:-14px; --dy:-10px"></span>
                <span style="--dx:8px;  --dy:-14px"></span>
                <span style="--dx:-4px; --dy:-18px"></span>
              </div>

              <span class="polvo polvo--a" aria-hidden="true"></span>
              <span class="polvo polvo--b" aria-hidden="true"></span>

              <!-- raíl y vagoneta: sube cargada, vuelve vacía -->
              <span class="rail" aria-hidden="true"></span>
              <span class="traviesas" aria-hidden="true"></span>
              <div class="vagoneta" aria-hidden="true">
                <span class="caja"></span>
                <span class="mineral"></span>
                <span class="rueda rueda--i"></span>
                <span class="rueda rueda--d"></span>
              </div>

              <span class="suelo" aria-hidden="true"></span>
            </div>
          } @else {
            <!-- ===== escena genérica: el taller ===== -->
            <div class="escena escena--taller">
              <div class="estratos estratos--taller" aria-hidden="true"></div>
              <span class="cable" aria-hidden="true"></span>
              <span class="halo" aria-hidden="true"></span>
              <span class="llama" aria-hidden="true"></span>

              <!-- el operario dando al yunque -->
              <div class="picador picador--taller" aria-hidden="true">
                <div class="pico pico--martillo">
                  <span class="mango mango--corto"></span>
                  <span class="hoja-pico hoja-pico--maza"></span>
                </div>
                <span class="tronco"></span>
                <span class="pecho"></span>
                <span class="cabeza"></span>
              </div>
              <span class="yunque" aria-hidden="true"></span>
              <div class="chispas chispas--taller" aria-hidden="true">
                <span style="--dx:-12px; --dy:-12px"></span>
                <span style="--dx:10px;  --dy:-10px"></span>
                <span style="--dx:0px;   --dy:-18px"></span>
              </div>

              <!-- el montón de monedas subiendo en el mostrador -->
              <div class="monedas" aria-hidden="true">
                <span></span><span></span><span></span><span></span>
              </div>

              <span class="mostrador" aria-hidden="true"></span>
              <span class="suelo" aria-hidden="true"></span>
            </div>
          }

          <!-- lectura de lo que va dando -->
          <div class="lectura">
            <div class="lec-franja">
              <span class="rotulo">Turno en curso</span>
              <span class="lec-pct">{{ p.incomePerDay }}</span>
            </div>
            <div class="lec-barra"><i></i></div>
          </div>

          <dl class="cuentas">
            <div><dt>{{ esMina(p) ? 'Mineral en la boca' : 'Caja del turno' }}</dt><dd>{{ p.pending }}</dd></div>
            <div><dt>Nivel de la propiedad</dt><dd>{{ p.level }} de {{ p.maxLevel }}</dd></div>
            <div class="cuentas--total"><dt>Para la bolsa</dt><dd>{{ p.pending }}</dd></div>
          </dl>

          @if (p.upgradeCost) {
            <p class="apunte">
              Sube a nivel {{ p.level + 1 }} por {{ p.upgradeCost }} y trabajará más rápido.
            </p>
          } @else {
            <p class="apunte">Está a nivel máximo: no dará más de lo que ves.</p>
          }

          <div class="obra-acc">
            <button class="boton boton--lacre"
                    [disabled]="p.pendingCp <= 0 || !!ocupado()"
                    (click)="recaudarYCerrar(p)">
              {{ p.pendingCp > 0 ? 'Recoger ' + p.pending : 'Nada que recoger' }}
            </button>
            <button class="boton boton--claro" (click)="cerrar()">Subir</button>
          </div>
        </div>
      </div>
    }
  `,
  styles: `
    .separador { margin-top: 26px; }
    .vacio {
      font-family: var(--cuerpo);
      font-style: italic;
      color: var(--sepia);
      margin: 8px 0 0;
    }
    .lista { list-style: none; margin: 10px 0 0; padding: 0; display: grid; gap: 12px; }

    .negocio { padding: 16px 18px; }
    .neg-cabe { display: flex; align-items: center; gap: 12px; }
    .emoji { font-size: 26px; line-height: 1; }
    .neg-id { flex: 1; min-width: 0; }
    .neg-id h2 { margin: 0; font-size: 19px; color: var(--tinta); }
    .neg-sub {
      margin: 2px 0 0;
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .1em;
      text-transform: uppercase;
      color: var(--sepia);
    }
    .nivel { display: flex; gap: 4px; }
    .punto {
      width: 9px; height: 9px; border-radius: 50%;
      border: 1px solid var(--oro);
      background: transparent;
    }
    .punto.lleno { background: var(--oro); }

    .neg-datos {
      display: flex; gap: 28px;
      margin: 14px 0;
      padding: 10px 0;
      border-top: 1px solid var(--linea);
      border-bottom: 1px solid var(--linea);
    }
    .neg-datos dt {
      font-family: var(--dato);
      font-size: 10px; letter-spacing: .1em; text-transform: uppercase;
      color: var(--sepia);
    }
    .neg-datos dd { margin: 3px 0 0; font-family: var(--dato); font-size: 15px; color: var(--tinta); }
    .acumulado dd { color: var(--sepia); }
    .acumulado dd.hay { color: var(--oro); font-weight: 600; }

    /* Invitación a entrar en la propiedad. Discreta pero de ancho completo:
       es lo que se toca desde el móvil. */
    .ver-obra {
      width: 100%;
      display: flex; align-items: center; justify-content: space-between;
      gap: 12px;
      background: transparent;
      border: 1px dashed var(--linea-fuerte);
      border-radius: var(--radio);
      padding: 11px 13px;
      margin-bottom: 12px;
      min-height: 44px;
    }
    .ver-obra:hover { background: rgba(43,33,23,.05); }
    .ver-texto {
      font-family: var(--dato);
      font-size: 10px; letter-spacing: .12em; text-transform: uppercase;
      color: var(--sepia-hondo);
    }
    .ver-flecha { color: var(--vino); font-family: var(--dato); }

    .neg-acc { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; }
    .tope {
      font-family: var(--dato);
      font-size: 10px; letter-spacing: .1em; text-transform: uppercase;
      color: var(--musgo);
    }

    .catalogo {
      list-style: none; margin: 10px 0 0; padding: 0;
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 12px;
    }
    .tipo { padding: 14px 16px; display: flex; flex-direction: column; }
    .tipo-cabe { display: flex; align-items: center; gap: 10px; }
    .tipo-cabe h3 { margin: 0; font-size: 17px; color: var(--tinta); }
    .tipo-blurb {
      font-family: var(--cuerpo);
      font-size: 14px; color: var(--sepia-hondo);
      margin: 8px 0 10px; flex: 1;
    }
    .tipo-datos { display: flex; justify-content: space-between; align-items: baseline; margin: 0 0 12px; }
    .precio { font-family: var(--dato); font-size: 15px; color: var(--oro); }
    .renta { font-family: var(--dato); font-size: 11px; color: var(--sepia); }
    .ancho { width: 100%; }

    .compra { display: grid; gap: 8px; }
    .nombre {
      width: 100%;
      font-family: var(--cuerpo);
      padding: 7px 9px;
    }
    .compra-acc { display: flex; gap: 8px; }
    .compra-acc .boton { flex: 1; }

    .boton-quitar {
      font-family: var(--dato);
      font-size: 11px;
      letter-spacing: .06em;
      color: var(--vino);
      background: transparent;
      border: 1px solid rgba(143,46,34,.4);
      border-radius: var(--radio);
      padding: 7px 12px;
      cursor: pointer;
    }
    .boton-quitar:hover:not(:disabled) { background: rgba(143,46,34,.08); }
    .boton-quitar:disabled { opacity: .5; cursor: default; }

    .estado--mal { color: var(--vino); }

    /* ==================================================================
       LA PROPIEDAD TRABAJANDO
       Todo es CSS: no hay imágenes ni SVG. La escena es un corte lateral
       de la galería (o del taller) visto desde el raíl.
       ================================================================== */

    .obra {
      position: fixed;
      inset: 0;
      z-index: 40;
      overflow-y: auto;
      background: var(--noche-honda);
      background-image: radial-gradient(70% 45% at 50% 22%, rgba(157,122,47,.22), transparent 70%);
      animation: obra-entra .25s ease both;
    }
    .obra-interior { max-width: 520px; margin: 0 auto; padding: 22px 18px 40px; }

    .obra-cabe {
      display: flex; align-items: center; justify-content: space-between;
      gap: 12px; margin-bottom: 18px;
    }
    .obra-cabe .rotulo { color: var(--oro); margin: 0; }
    .obra-cabe h2 {
      font-family: var(--display);
      font-size: 26px; line-height: 1.1;
      color: var(--pergamino);
      margin: 4px 0 0;
    }
    .cerrar {
      flex: 0 0 auto;
      width: 44px; height: 44px;
      border: 1px solid rgba(239,228,205,.28);
      border-radius: var(--radio);
      background: transparent;
      color: #c9b998;
      font-family: var(--dato);
      font-size: 15px;
    }
    .cerrar:hover { background: rgba(239,228,205,.08); }

    /* ------------------------------------------------------- la escena */
    .escena {
      position: relative;
      height: 270px;
      border: 1px solid var(--linea-noche);
      border-radius: var(--radio);
      overflow: hidden;
      background: linear-gradient(180deg, #2a2015 0%, #1d1510 55%, #140f0a 100%);
    }
    .estratos {
      position: absolute; inset: 0;
      opacity: .5;
      background-image:
        repeating-linear-gradient(96deg, rgba(0,0,0,.28) 0 3px, transparent 3px 22px),
        repeating-linear-gradient(4deg, rgba(255,240,210,.04) 0 1px, transparent 1px 34px);
    }
    .estratos--taller {
      opacity: .35;
      background-image: repeating-linear-gradient(90deg, rgba(0,0,0,.3) 0 2px, transparent 2px 30px);
    }

    /* candil */
    .cable { position: absolute; top: 0; left: 44px; width: 2px; height: 34px; background: rgba(239,228,205,.3); }
    .halo {
      position: absolute; top: 30px; left: 26px;
      width: 38px; height: 38px; border-radius: 50%;
      background: radial-gradient(circle, rgba(230,201,131,.85), rgba(157,122,47,0) 70%);
      animation: obra-candil 2.6s ease-in-out infinite;
    }
    .llama {
      position: absolute; top: 44px; left: 41px;
      width: 8px; height: 11px; border-radius: 2px;
      background: #e6c983;
      box-shadow: 0 0 14px rgba(230,201,131,.9);
    }

    /* goteo */
    .gota {
      position: absolute; top: 8px;
      width: 2px; height: 8px; border-radius: 1px;
      background: rgba(200,225,235,.6);
      animation: obra-gota 3.4s linear infinite;
    }
    .gota--a { left: 172px; }
    .gota--b { left: 298px; animation-delay: 1.7s; }

    /* la veta */
    .veta {
      position: absolute; top: 96px; right: 34px;
      width: 96px; height: 8px; border-radius: 4px;
      background: linear-gradient(90deg, #9d7a2f, #e6c983, #9d7a2f);
      opacity: .75;
      transform: rotate(-9deg);
      box-shadow: 0 0 18px rgba(230,201,131,.35);
    }
    .veta--fina {
      top: 118px; right: 56px;
      width: 52px; height: 5px;
      background: #9d7a2f;
      opacity: .5;
      transform: rotate(-6deg);
      box-shadow: none;
    }

    /* el picador */
    .picador {
      position: absolute; bottom: 56px; right: 96px;
      width: 78px; height: 96px;
      animation: obra-picador 1.5s ease-in-out infinite;
    }
    .picador--taller { bottom: 62px; right: 130px; }

    .pico {
      position: absolute; top: 6px; left: 26px;
      width: 52px; height: 46px;
      transform-origin: 6px 40px;
      animation: obra-pico 1.5s cubic-bezier(.3,.05,.2,1) infinite;
    }
    .mango {
      position: absolute; bottom: 0; left: 3px;
      width: 48px; height: 4px; border-radius: 2px;
      background: #7a5b34;
      transform: rotate(-24deg);
      transform-origin: 0 50%;
    }
    .mango--corto { width: 34px; }
    .hoja-pico {
      position: absolute; top: -4px; right: -4px;
      width: 22px; height: 6px; border-radius: 3px;
      background: linear-gradient(90deg, #c9b998, #8a7658);
      transform: rotate(38deg);
    }
    .hoja-pico--maza {
      top: -8px; right: 6px;
      width: 16px; height: 14px; border-radius: 2px;
      transform: rotate(20deg);
    }

    .tronco { position: absolute; bottom: 0; left: 20px; width: 22px; height: 36px; border-radius: 3px 3px 1px 1px; background: #3f3325; }
    .pecho  { position: absolute; bottom: 34px; left: 22px; width: 18px; height: 22px; border-radius: 3px; background: #4a3b28; }
    .cabeza { position: absolute; bottom: 54px; left: 24px; width: 15px; height: 14px; border-radius: 50% 50% 40% 40%; background: #6b5335; }
    .casco  { position: absolute; bottom: 66px; left: 22px; width: 19px; height: 6px; border-radius: 3px 3px 0 0; background: #8a7658; }

    /* chispas del golpe */
    .chispas { position: absolute; bottom: 118px; right: 74px; width: 4px; height: 4px; }
    .chispas--taller { bottom: 104px; right: 118px; }
    .chispas span {
      position: absolute;
      width: 3px; height: 3px; border-radius: 50%;
      background: #e6c983;
      animation: obra-chispa 1.5s linear infinite;
    }
    .chispas span:nth-child(2) { background: #f5ecd8; }
    .chispas span:nth-child(3) { width: 2px; height: 2px; background: #9d7a2f; }

    /* polvo suspendido */
    .polvo {
      position: absolute;
      border-radius: 50%;
      background: rgba(201,185,152,.32);
      filter: blur(3px);
      animation: obra-polvo 3s ease-out infinite;
    }
    .polvo--a { bottom: 100px; right: 64px;  width: 12px; height: 12px; }
    .polvo--b { bottom: 104px; right: 118px; width: 16px; height: 16px; animation-duration: 3.6s; animation-delay: 1.1s; }

    /* raíl y vagoneta */
    .rail {
      position: absolute; bottom: 34px; left: 0; right: 0; height: 3px;
      background: linear-gradient(90deg,
        rgba(138,118,88,.15), rgba(201,185,152,.55) 20%,
        rgba(201,185,152,.55) 80%, rgba(138,118,88,.15));
    }
    .traviesas {
      position: absolute; bottom: 22px; left: 0; right: 0; height: 10px;
      background-image: repeating-linear-gradient(90deg, rgba(122,91,52,.7) 0 5px, transparent 5px 26px);
    }
    .vagoneta {
      position: absolute; bottom: 37px; left: 18px;
      width: 64px; height: 44px;
      animation: obra-vagoneta 5.4s ease-in-out infinite;
    }
    .caja {
      position: absolute; bottom: 9px; left: 0;
      width: 64px; height: 26px; border-radius: 2px 2px 4px 4px;
      background: linear-gradient(180deg, #5a4630, #3a2c1d);
      border: 1px solid rgba(239,228,205,.22);
    }
    /* la carga se vacía arriba y la vagoneta vuelve sin nada */
    .mineral {
      position: absolute; bottom: 32px; left: 8px;
      width: 48px; height: 12px; border-radius: 8px 8px 2px 2px;
      background: linear-gradient(180deg, #e6c983, #9d7a2f);
      box-shadow: 0 0 12px rgba(230,201,131,.4);
      animation: obra-carga 5.4s ease-in-out infinite;
    }
    .rueda {
      position: absolute; bottom: 0;
      width: 16px; height: 16px; border-radius: 50%;
      border: 2px solid #c9b998;
      animation: obra-rueda 1.1s linear infinite;
    }
    .rueda--i { left: 9px; }
    .rueda--d { right: 9px; }
    .rueda::after {
      content: '';
      position: absolute; top: 5px; left: -1px;
      width: 14px; height: 2px; background: #c9b998;
    }

    /* taller: yunque, mostrador y monedas que suben */
    .yunque {
      position: absolute; bottom: 34px; right: 96px;
      width: 44px; height: 22px;
      border-radius: 3px 3px 1px 1px;
      background: linear-gradient(180deg, #4a3b28, #2a2015);
      border: 1px solid rgba(239,228,205,.18);
    }
    .mostrador {
      position: absolute; bottom: 22px; left: 34px;
      width: 128px; height: 8px;
      background: linear-gradient(180deg, #5a4630, #3a2c1d);
      border-top: 1px solid rgba(239,228,205,.2);
    }
    .monedas { position: absolute; bottom: 30px; left: 58px; width: 40px; height: 60px; }
    .monedas span {
      position: absolute; left: 0;
      width: 34px; height: 7px; border-radius: 50%;
      background: linear-gradient(180deg, #e6c983, #9d7a2f);
      box-shadow: 0 0 10px rgba(230,201,131,.3);
      animation: obra-moneda 4.4s ease-out infinite;
    }
    .monedas span:nth-child(1) { bottom: 0;  animation-delay: 0s; }
    .monedas span:nth-child(2) { bottom: 7px;  animation-delay: 1.1s; }
    .monedas span:nth-child(3) { bottom: 14px; animation-delay: 2.2s; }
    .monedas span:nth-child(4) { bottom: 21px; animation-delay: 3.3s; }

    .suelo {
      position: absolute; bottom: 0; left: 0; right: 0; height: 22px;
      background: linear-gradient(180deg, #0f0b07, #1a130d);
    }

    /* ------------------------------------------- lectura bajo la escena */
    .lectura { margin-top: 18px; display: grid; gap: 9px; }
    .lec-franja { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; }
    .lec-franja .rotulo { color: var(--sepia-claro); margin: 0; }
    .lec-pct { font-family: var(--dato); font-size: 12px; color: var(--oro-claro); }
    .lec-barra { height: 4px; background: rgba(239,228,205,.14); border-radius: 2px; overflow: hidden; }
    .lec-barra > i { display: block; height: 100%; background: var(--oro); animation: obra-llena 1.4s ease-out both; }

    .cuentas {
      margin: 20px 0 0;
      padding-top: 18px;
      border-top: 1px solid var(--linea-noche);
      display: grid; gap: 10px;
    }
    .cuentas > div { display: flex; justify-content: space-between; gap: 12px; align-items: baseline; }
    .cuentas dt { font-family: var(--dato); font-size: 12px; color: var(--sepia-claro); }
    .cuentas dd { margin: 0; font-family: var(--dato); font-size: 12px; color: var(--pergamino); }
    .cuentas--total {
      border-top: 1px solid var(--linea-noche);
      padding-top: 12px;
    }
    .cuentas--total dt, .cuentas--total dd { font-size: 15px; }
    .cuentas--total dd { color: var(--oro-claro); }

    .apunte {
      margin: 16px 0 0;
      font-size: 16px; line-height: 1.5;
      color: var(--sepia-claro);
      font-style: italic;
    }

    .obra-acc { margin-top: 22px; display: flex; gap: 10px; flex-wrap: wrap; }
    .obra-acc .boton { flex: 1 1 150px; }
    .boton--claro {
      background: transparent;
      border-color: rgba(239,228,205,.32);
      color: var(--pergamino);
    }
    .boton--claro:hover { background: rgba(239,228,205,.1); }

    /* ------------------------------------------------------ animaciones */
    /* El pico: sube, cae y el impacto frena de golpe. */
    @keyframes obra-pico {
      0%, 42% { transform: rotate(-58deg); }
      58%     { transform: rotate(14deg); }
      66%     { transform: rotate(4deg); }
      100%    { transform: rotate(-58deg); }
    }
    @keyframes obra-chispa {
      0%, 54% { opacity: 0; transform: translate(0,0) scale(.4); }
      60%     { opacity: 1; transform: translate(var(--dx), var(--dy)) scale(1); }
      78%, 100% { opacity: 0; transform: translate(calc(var(--dx) * 1.7), calc(var(--dy) * 1.7 + 6px)) scale(.5); }
    }
    @keyframes obra-vagoneta {
      0%       { transform: translateX(-14px); }
      46%, 54% { transform: translateX(150px); }
      100%     { transform: translateX(-14px); }
    }
    @keyframes obra-carga {
      0%, 44%  { opacity: 1; }
      52%, 96% { opacity: 0; }
      100%     { opacity: 1; }
    }
    @keyframes obra-rueda { to { transform: rotate(360deg); } }
    @keyframes obra-polvo {
      0%   { opacity: 0; transform: translateY(0) scale(.6); }
      30%  { opacity: .5; }
      100% { opacity: 0; transform: translateY(-46px) scale(1.8); }
    }
    @keyframes obra-candil {
      0%, 100% { opacity: .55; transform: scale(1); }
      50%      { opacity: 1; transform: scale(1.08); }
    }
    @keyframes obra-picador {
      0%, 100% { transform: translateY(0); }
      50%      { transform: translateY(2px); }
    }
    @keyframes obra-gota {
      0%   { opacity: 0; transform: translateY(-4px); }
      20%  { opacity: .7; }
      100% { opacity: 0; transform: translateY(30px); }
    }
    @keyframes obra-moneda {
      0%       { opacity: 0; transform: translateY(10px) scaleX(.7); }
      18%, 88% { opacity: 1; transform: none; }
      100%     { opacity: 0; transform: translateY(-4px); }
    }
    @keyframes obra-llena { from { width: 0; } to { width: 64%; } }
    @keyframes obra-entra {
      from { opacity: 0; transform: translateY(10px); }
      to   { opacity: 1; transform: none; }
    }

    @media (prefers-reduced-motion: reduce) {
      .obra *, .obra { animation: none !important; }
      .lec-barra > i { width: 64%; }
    }
  `,
})
export class PropiedadesPage implements OnInit {

  readonly personajeId = input.required<string>();

  private readonly juego = inject(JuegoService);

  readonly datos = signal<Holdings | null>(null);
  readonly cargando = signal(true);
  readonly error = signal<string | null>(null);

  /** id de la propiedad (o 'comprar') en curso, para bloquear botones. */
  readonly ocupado = signal<string | null>(null);
  /** código del tipo cuyo formulario de compra está abierto. */
  readonly eligiendo = signal<string | null>(null);
  readonly nombre = signal('');

  /** id de la propiedad que se está viendo trabajar, o null. */
  readonly viendo = signal<string | null>(null);

  /** La propiedad abierta, leída siempre de `datos` para que recaudar la
   *  actualice en sitio sin cerrar la escena. */
  readonly abierta = computed<Property | null>(() => {
    const id = this.viendo();
    if (!id) return null;
    return this.datos()?.properties.find(p => p.id === id) ?? null;
  });

  /** [1..max] para pintar los puntos de nivel. */
  niveles = (max: number) => Array.from({ length: max }, (_, i) => i + 1);

  /** La mina tiene su propia escena (picador, veta, vagoneta). El resto de
   *  negocios comparten la del taller. */
  esMina(p: Property): boolean {
    const k = `${p.kind} ${p.tipo}`.toLowerCase();
    return k.includes('min') || k.includes('cantera') || k.includes('pozo');
  }

  ngOnInit(): void {
    this.juego.propiedades(this.personajeId()).subscribe({
      next: d => { this.datos.set(d); this.cargando.set(false); },
      error: () => {
        this.cargando.set(false);
        this.error.set('No se han podido cargar las propiedades.');
      },
    });
  }

  // --- ver la propiedad trabajando ---

  abrir(p: Property): void { this.viendo.set(p.id); }
  cerrar(): void { this.viendo.set(null); }

  /** Recaudar desde dentro de la escena y subir. */
  recaudarYCerrar(p: Property): void {
    if (p.pendingCp <= 0) return;
    this.recaudar(p);
    this.cerrar();
  }

  recaudar(p: Property): void {
    if (this.ocupado()) return;
    this.ocupado.set(p.id);
    this.error.set(null);
    this.juego.recaudarPropiedad(this.personajeId(), p.id).subscribe({
      next: d => { this.datos.set(d); this.ocupado.set(null); },
      error: err => this.fallo(err, 'No se ha podido recaudar.'),
    });
  }

  mejorar(p: Property): void {
    if (this.ocupado()) return;
    this.ocupado.set(p.id);
    this.error.set(null);
    this.juego.mejorarPropiedad(this.personajeId(), p.id).subscribe({
      next: d => { this.datos.set(d); this.ocupado.set(null); },
      error: err => this.fallo(err, 'No se ha podido mejorar.'),
    });
  }

  vender(p: Property): void {
    if (this.ocupado()) return;
    // Confirmación simple: vender es destructivo.
    if (!confirm(`¿Vender "${p.name}" por ${p.saleValue}? (más la renta acumulada)`)) return;
    this.ocupado.set(p.id);
    this.error.set(null);
    this.juego.venderPropiedad(this.personajeId(), p.id).subscribe({
      next: d => {
        this.datos.set(d);
        this.ocupado.set(null);
        if (this.viendo() === p.id) this.cerrar();
      },
      error: err => this.fallo(err, 'No se ha podido vender.'),
    });
  }

  // --- compra ---

  elegir(c: PropertyCatalogItem): void {
    this.eligiendo.set(c.kind);
    this.nombre.set('');
  }

  cancelar(): void {
    this.eligiendo.set(null);
    this.nombre.set('');
  }

  confirmar(c: PropertyCatalogItem): void {
    if (this.ocupado()) return;
    this.ocupado.set('comprar');
    this.error.set(null);
    this.juego.comprarPropiedad(this.personajeId(), {
      kind: c.kind,
      name: this.nombre().trim() || c.nombre,
    }).subscribe({
      next: d => {
        this.datos.set(d);
        this.ocupado.set(null);
        this.eligiendo.set(null);
        this.nombre.set('');
      },
      error: err => this.fallo(err, 'No se ha podido comprar.'),
    });
  }

  private fallo(err: unknown, porDefecto: string): void {
    this.ocupado.set(null);
    const e = err as { error?: { message?: string } };
    this.error.set(e?.error?.message ?? porDefecto);
  }
}
