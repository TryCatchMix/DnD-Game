import { Component, inject, signal, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { JuegoService } from '../../core/juego.service';
import { AuthService } from '../../core/auth.service';
import { Character } from '../../core/api.types';
import { NavBar } from '../../shared/nav';

/**
 * Pantalla 01: elegir con qué personaje juegas.
 *
 * Es el libro de registro del clan: una fila por nombre, con el retrato al
 * borde, la línea de raza y clase en versalitas, y el estado a la derecha
 * (Vigor disponible o "en curso" si ese personaje ya está trabajando).
 */
@Component({
  selector: 'arc-characters',
  imports: [NavBar],
  template: `
    <arc-nav />
    <div class="contenedor">
      <header class="cabecera">
        <p class="rotulo">Registro del clan · Los Archivos</p>
        <h1>¿Con quién bajas hoy?</h1>
      </header>

      @if (cargando()) {
        <p class="estado">Abriendo el registro…</p>
      } @else if (error(); as e) {
        <p class="estado estado--mal" role="alert">{{ e }}</p>
      } @else if (personajes().length === 0) {
        <p class="estado">No hay personajes en tu registro todavía. Crea el primero.</p>
      } @else {
        <ul class="lista">
          @for (p of personajes(); track p.id) {
            <li class="hoja ficha" (click)="elegir(p)">

              <!-- El retrato va vacío a propósito: es el hueco donde el
                   jugador pega su ilustración cuando la tenga. -->
              <span class="retrato" aria-hidden="true"></span>

              <span class="identidad">
                <span class="nombre">{{ p.name }}</span>
                <span class="linea-clase">
                  @if (p.ancestry) { {{ p.ancestry }} }
                  @if (p.ancestry && p.role) { · }
                  @if (p.role) { {{ p.role }} }
                  @if (p.level) { · Nivel {{ p.level }} }
                </span>
              </span>

              <span class="estado-col">
                @if (p.vigor != null) {
                  <span class="vigor" [class.vigor--seco]="p.vigor === 0">
                    Vigor {{ p.vigor }}@if (p.maxVigor != null) {/{{ p.maxVigor }}}
                  </span>
                }
                @if (p.location) { <span class="lugar">{{ p.location }}</span> }
              </span>

              <span class="atajos">
                <button class="atajo" (click)="verFicha(p, $event)">Ficha</button>
                <button class="atajo" (click)="verTienda(p, $event)">Tienda</button>
              </span>
            </li>
          }
        </ul>

        <p class="nota-vigor">El Vigor se repone con el tiempo real. Nadie farmea aquí.</p>
      }

      <div class="acciones">
        <button class="boton boton--lacre" (click)="crear()">+ Crear personaje</button>
        <button class="boton" (click)="salir()">Salir del registro</button>
      </div>
    </div>
  `,
  styles: `
    .cabecera { margin-bottom: 22px; }
    .cabecera h1 { font-size: 30px; color: var(--pergamino); margin-top: 6px; line-height: 1.1; }
    .cabecera .rotulo { color: var(--sepia-claro); }

    .lista { list-style: none; margin: 0 0 14px; padding: 0; display: grid; gap: 10px; }

    /* La fila del registro: retrato · identidad · estado, y los atajos abajo
       para que el objetivo táctil de la fila entera siga siendo "elegir". */
    .ficha {
      display: grid;
      grid-template-columns: 52px 1fr auto;
      align-items: center;
      column-gap: 14px;
      row-gap: 10px;
      padding: 14px 16px;
      min-height: 80px;
      cursor: pointer;
      transition: transform .12s ease, box-shadow .12s ease;
    }
    .ficha:hover {
      transform: translateY(-1px);
      box-shadow: 0 1px 0 rgba(255,255,255,.35) inset, 0 16px 32px rgba(0,0,0,.5);
    }

    .retrato {
      width: 52px; height: 52px;
      border: 1px solid var(--linea-fuerte);
      border-radius: var(--radio);
      background: repeating-linear-gradient(45deg, #d9c9a6 0 4px, #cdbb93 4px 8px);
    }

    .identidad { min-width: 0; display: grid; gap: 4px; }
    .nombre {
      font-family: var(--display);
      font-size: 24px;
      line-height: 1;
      color: var(--tinta);
    }
    .linea-clase {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .1em;
      text-transform: uppercase;
      color: var(--sepia);
    }

    .estado-col { display: grid; gap: 4px; text-align: right; white-space: nowrap; }
    .vigor { font-family: var(--dato); font-size: 11px; color: var(--musgo); }
    .vigor--seco { color: var(--vino); }
    .lugar {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .08em;
      text-transform: uppercase;
      color: var(--sepia);
    }

    .atajos {
      grid-column: 2 / -1;
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      border-top: 1px solid var(--linea-clara);
      padding-top: 10px;
    }
    .atajo {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .12em;
      text-transform: uppercase;
      color: var(--vino);
      background: transparent;
      border: 1px solid rgba(143,46,34,.4);
      border-radius: var(--radio);
      padding: 7px 12px;
    }
    .atajo:hover { background: rgba(143,46,34,.08); }

    .nota-vigor {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .12em;
      text-transform: uppercase;
      color: var(--sepia);
      text-align: center;
      margin: 0 0 24px;
    }

    .acciones { display: flex; gap: 12px; flex-wrap: wrap; }

    .estado { font-style: italic; color: var(--sepia-claro); padding: 28px 0; }
    .estado--mal { color: #d98a7c; font-style: normal; }

    @media (max-width: 420px) {
      .ficha { grid-template-columns: 44px 1fr; }
      .retrato { width: 44px; height: 44px; }
      .estado-col { grid-column: 2; text-align: left; }
      .atajos { grid-column: 1 / -1; justify-content: flex-start; }
    }
  `,
})
export class CharactersPage implements OnInit {

  private readonly juego = inject(JuegoService);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  readonly personajes = signal<Character[]>([]);
  readonly cargando = signal(true);
  readonly error = signal<string | null>(null);

  ngOnInit(): void {
    this.juego.personajes().subscribe({
      next: ps => { this.personajes.set(ps); this.cargando.set(false); },
      error: () => {
        this.cargando.set(false);
        this.error.set('No se ha podido leer el registro del clan.');
      },
    });
  }

  crear(): void {
    void this.router.navigate(['/personajes', 'nuevo']);
  }

  elegir(p: Character): void {
    void this.router.navigate(['/personajes', p.id, 'tablon']);
  }

  verFicha(p: Character, ev: Event): void {
    ev.stopPropagation();   // no queremos que además navegue al tablón
    void this.router.navigate(['/personajes', p.id, 'ficha']);
  }

  verTienda(p: Character, ev: Event): void {
    ev.stopPropagation();
    void this.router.navigate(['/personajes', p.id, 'tienda']);
  }

  salir(): void {
    this.auth.logout();
  }
}
