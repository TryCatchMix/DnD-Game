import { Component, computed, inject, input } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

import { AuthService } from '../core/auth.service';

/**
 * Barra de pestañas del clan. Está siempre visible, pegada arriba, y muestra
 * TODAS las rutas a la vez: nunca se esconde nada detrás de un scroll ni de un
 * menú. En móvil las pestañas se reparten en dos o tres líneas antes que
 * desaparecer, porque saber a dónde puedes ir es parte del juego.
 *
 * `personajeId` es opcional: en el registro del clan (cuando aún no has
 * elegido personaje) las pestañas que necesitan uno se ven apagadas.
 */
@Component({
  selector: 'arc-nav',
  imports: [RouterLink, RouterLinkActive],
  template: `
    <nav class="barra">
      <div class="interior">
        <a class="tab tab--registro" [routerLink]="['/personajes']"
           routerLinkActive="activa" [routerLinkActiveOptions]="{ exact: true }">Registro</a>

        @if (pid()) {
          <a class="tab" [routerLink]="['/personajes', pid(), 'tablon']"
             routerLinkActive="activa">Tablón</a>
          <a class="tab" [routerLink]="['/personajes', pid(), 'escena']"
             routerLinkActive="activa">Escena</a>
          <a class="tab" [routerLink]="['/personajes', pid(), 'ficha']"
             routerLinkActive="activa">Ficha</a>
          <a class="tab tab--oro" [routerLink]="['/personajes', pid(), 'tienda']"
             routerLinkActive="activa">Tienda</a>
          <a class="tab tab--oro" [routerLink]="['/personajes', pid(), 'propiedades']"
             routerLinkActive="activa">Propiedades</a>
          <a class="tab" [routerLink]="['/personajes', pid(), 'cronica']"
             routerLinkActive="activa">Crónica</a>
          <a class="tab tab--arcano" [routerLink]="['/personajes', pid(), 'hechizos']"
             routerLinkActive="activa">Hechizos</a>
          <a class="tab tab--nota" [routerLink]="['/personajes', pid(), 'notas']"
             routerLinkActive="activa">Notas</a>
          @if (esDM()) {
            <a class="tab tab--dm" [routerLink]="['/personajes', pid(), 'dm']"
               routerLinkActive="activa">Encargos (DM)</a>
          }
        } @else {
          <span class="tab tab--apagada">Tablón</span>
          <span class="tab tab--apagada">Escena</span>
          <span class="tab tab--apagada">Ficha</span>
          <span class="tab tab--apagada">Tienda</span>
          <span class="tab tab--apagada">Propiedades</span>
          <span class="tab tab--apagada">Crónica</span>
          <span class="tab tab--apagada">Hechizos</span>
          <span class="tab tab--apagada">Notas</span>
        }
      </div>
    </nav>
  `,
  styles: `
    /* Siempre arriba, siempre visible: sticky en todos los tamaños. */
    .barra {
      position: sticky;
      top: 0;
      z-index: 20;
      background: rgba(23, 18, 8, .95);
      backdrop-filter: blur(8px);
      border-bottom: 1px solid var(--linea-noche);
    }

    /* Se reparten en varias líneas antes que ocultarse. */
    .interior {
      max-width: 720px;
      margin: 0 auto;
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
      padding: 8px 12px;
    }

    .tab {
      font-family: var(--dato);
      font-size: 10px;
      letter-spacing: .12em;
      text-transform: uppercase;
      color: var(--sepia-claro);
      text-decoration: none;
      padding: 8px 11px;
      border: 1px solid transparent;
      border-radius: var(--radio);
      white-space: nowrap;
    }
    .tab:hover { color: var(--pergamino); background: rgba(239, 228, 205, .06); }

    .tab.activa {
      color: var(--pergamino);
      border-color: var(--linea-noche);
      background: rgba(239, 228, 205, .08);
      box-shadow: inset 0 -2px 0 var(--vino);
    }

    .tab--registro { color: var(--sepia); }
    .tab--oro { color: var(--oro); }
    .tab--oro.activa { color: var(--oro-claro); box-shadow: inset 0 -2px 0 var(--oro); }
    .tab--dm { color: var(--musgo); }
    .tab--dm.activa { color: #6a8a4f; box-shadow: inset 0 -2px 0 var(--musgo); }
    .tab--arcano { color: #8a7bb0; }
    .tab--arcano.activa { color: #a294c9; box-shadow: inset 0 -2px 0 #8a7bb0; }
    .tab--nota { color: var(--oro); }
    .tab--nota.activa { color: var(--oro-claro); box-shadow: inset 0 -2px 0 var(--oro); }

    /* Sin personaje elegido: se ven, pero apagadas. */
    .tab--apagada { color: var(--sepia); opacity: .45; cursor: default; }
  `,
})
export class NavBar {
  /** Opcional: en el registro del clan todavía no hay personaje. */
  readonly personajeId = input<string | null>(null);

  readonly pid = computed(() => this.personajeId() ?? null);

  private readonly auth = inject(AuthService);
  readonly esDM = computed(() => this.auth.rol() === 'DM');
}
